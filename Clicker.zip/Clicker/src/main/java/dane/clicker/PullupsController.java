package dane.clicker;

public class PullupsController extends SquatController{
}
